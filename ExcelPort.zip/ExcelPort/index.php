<!doctype html>
<html lang="es">

<head>
  <title>Importar libro de Excel</title>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS v5.2.1 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">

</head>

<body>
  <header>
    <!-- place navbar here -->

    <nav class="navbar navbar-expand-lg navbar-light bg-light">
          <div class="container">
            <a class="navbar-brand" href="#">IMPORT EXCEL</a>
            <button class="navbar-toggler d-lg-none" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavId" aria-controls="collapsibleNavId"
                aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="collapsibleNavId">
                <ul class="navbar-nav me-auto mt-2 mt-lg-0">
                    <li class="nav-item">
                        <a class="nav-link active" href="#" aria-current="page">Home <span class="visually-hidden">(current)</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Link</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="dropdownId" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Dropdown</a>
                        <div class="dropdown-menu" aria-labelledby="dropdownId">
                            <a class="dropdown-item" href="#">Action 1</a>
                            <a class="dropdown-item" href="#">Action 2</a>
                        </div>
                    </li>
                </ul>
                <form class="d-flex my-2 my-lg-0">
                    <input class="form-control me-sm-2" type="text" placeholder="Search">
                    <button class="btn btn-outline-success my-2 my-sm-0" type="submit">BUSCAR</button>
                </form>
            </div>
      </div>
    </nav>
    

  </header>
  <br>
  <main>
    <div class="container">
        <form action="code.php" method="POST" enctype="multipart/form-data">

            <label for="formFile" class="form-label">Adjuntar Excel</label>

            <input required class="form-control" type="file" id="formFile" name="file" accept=".xlsx,.csv">

            <button type="submit" name="save_excel_data" class="btn btn-primary mt-3">Guardar</button>
        </form>
    </div>
    <br>
    <div class="container">
    <table class="table">
                                        <thead>
                                            <tr>
                                                <th scope="col">ID</th>
                                                <th scope="col">Nombre</th>
                                                <th scope="col">Apellido</th>
                                                <th scope="col">Correo</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php 
                                           require('conexion.php');
                                            $sql = "SELECT id, nombre, apellido, correo FROM user";
                                            $rta = mysqli_query($conexion, $sql);
                                            while ($mostrar = mysqli_fetch_row($rta)){
                                                ?>
                                            <tr>
                                                <th> <?php echo $mostrar["0"] ?> </th>
                                                <td><?php echo $mostrar["1"] ?></td>
                                                <td><?php echo $mostrar["2"] ?></td>
                                                <td><?php echo $mostrar["3"] ?></td> 
                                            </tr>
                                            <?php
                                            }
                                            ?>
                                        </tbody>
                                    </table>
</div>
  </main>
  <br>
  <footer>
    <!-- place footer here -->
    <div class="card">
        <div class="card-footer text-muted">
            BIENVENIDO
        </div>
    </div>
  </footer>
  <!-- Bootstrap JavaScript Libraries -->
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"
    integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous">
  </script>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.min.js"
    integrity="sha384-7VPbUDkoPSGFnVtYi0QogXtr74QeVeeIs99Qfg5YCF+TidwNdjvaKZX19NZ/e6oz" crossorigin="anonymous">
  </script>
</body>

</html>